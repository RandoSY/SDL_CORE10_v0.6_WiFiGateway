# SDL CORE 10 v0.6 - Independent Wi-Fi/TCP Gateway + Graphical Analysis

**Start here: `docs/00_START_HERE.md`.** On Windows, double-click **`START_DEMO.bat`** after extracting the entire ZIP. Python 3.10+ standard library; no extra packages, Docker or cloud required for the demo.

- Dashboard: `http://127.0.0.1:8788/`
- WebSocket: `ws://127.0.0.1:8788/ws/telemetry`
- Python health: `http://127.0.0.1:8788/api/status`
- TCP node: port `8766`; simulation launches on `127.0.0.1`
- Unit/integration tests: `py -3 -m unittest discover -s tests -v`
- Real instrument (experimental): `START_WIFI_NODE.bat <DEVICE_IP> [PORT]`

**Scope:** 10 CORE 10 simulations and 8 Vernier-inspired browser extensions from v0.5; Python TCP gateway with 5-second goodput, sample integrity, RTT and approximate lag. Default data are explicitly **synthetic**. The gateway is a **standalone sidecar**, not a modification to the historical SUPER SDL v0.7 MCP/SDL-ASCII service; it uses different ports and a different node protocol.

**Security:** local-only browser server; no TLS or authentication. Do not port-forward or connect to untrusted networks.

Learn the architecture via `docs/01_ARCHITECTURE_AND_LESSON.md` and printable `docs/ARCHITECTURE.svg`. Status and limitations in `docs/04_TEST_REPORT.md`.
