# Independent functional verification - 2026-11-08

## Automated verification

Executed within the working container:

```
cd SDL_CORE10_v0.6_WiFiGateway
python -m unittest discover -s tests -v
```

**Result: 8 tests passed, 0 failed, approximately 6 seconds.**

Tests:

1. `test_crc_good_and_rejected_bad`: accepts correct envelope CRC; rejects corrupted checksum.
2. `test_sequence_gap_duplicate_and_reordered`: counts missing sequence, repeated frame, out-of-order frame.
3. `test_rssi_is_explicit_report_not_derived`: treats RSSI as node-reported or missing.
4. `test_recent_health_window_recovers`: health score recovers when recent errors age out.
5. `test_bad_unicode_json`: malformed JSON handled as parse error.
6. `test_independent_http_and_node_stream`: real loopback TCP node -> gateway, HTTP status endpoint, nonempty throughput and RTT fields.
7. `test_websocket_metrics_and_simulated_live_samples`: real HTTP WebSocket upgrade and streaming `sdl.hello`, `sdl.metrics`, `sdl.sample` frames.
8. `test_fault_injection_causes_actual_integrity_counts`: injected missing samples, duplicate packets and corrupt CRC produce nonzero counters and degraded health score.

**Real networking mechanism:** Python's `asyncio.start_server` and `asyncio.open_connection`, not in-process function calls. The tests use OS-allocated free TCP ports on `127.0.0.1`.

## Explicit limitations

- **No Wi-Fi radio validation:** Test topology uses local loopback TCP, with a synthetic instrument.
- **No ESP32 firmware bench validation:** Arduino sample source included but not flashed.
- **Browser automation not completed:** Chromium in this working environment reports `ERR_BLOCKED_BY_ADMINISTRATOR` for both local HTTP and file URLs. The Python HTTP and RFC6455 WebSocket protocol were independently exercised. The final UI requires a manual smoke test on your Windows machine.
- **Not an integration with historic MCP service:** v0.6 is a standalone sidecar to coexist with prior SUPER SDL v0.7 infrastructure.
- **Application-level diagnostics only:** no Wi-Fi PHY link rate, RF interference survey, or retransmission counters; no guaranteed device clock synchronization.
- **Production hardening incomplete:** no login, TLS or remote network access, and the reference device adapter is intentionally read-only.

## Manual Windows acceptance checklist

- [ ] `START_DEMO.bat` opens the dashboard at `http://127.0.0.1:8788/`.
- [ ] In Connections select Python SDL Wi-Fi Gateway and Connect source.
- [ ] Status becomes Connected, and metrics update every second.
- [ ] In Live select Galileo, Start run, and watch synthetic mass-versus-time values grow.
- [ ] Stop, view Analysis, save to Archive, export CSV and JSON.
- [ ] Re-launch with fault flags and verify CRC, duplicate, and gap counters change.
- [ ] Stop the Python process and verify dashboard changes to offline.
- [ ] Restart the clean demo and verify connection recovers.
- [ ] Only after these pass, connect an ESP32 with the reference protocol and validate true physical source and reported RSSI.
