# SDL CORE 10 v0.6 - START HERE

**Deliverable:** independently runnable, Python-standard-library Wi-Fi/TCP telemetry gateway plus the existing five-tab CORE 10 graphical-analysis dashboard. **No Docker, Node, pip installs, or cloud account are required for the demo.**

## Windows: first successful experiment

1. Unzip the whole archive to a writable directory, e.g., `C:\SDL\SDL_CORE10_v0.6_WiFiGateway\`. Do not run individual HTML files directly out of ZIP.
2. Install Python 3.10 or newer if missing (`py -3 --version` verifies it).
3. Double-click `START_DEMO.bat`. This starts a **separate synthetic TCP instrument** and the **Python gateway** on your PC and opens `http://127.0.0.1:8788/`.
4. In the dashboard, select **Connections**. Choose **Python SDL Wi-Fi Gateway - live**. Confirm WebSocket URL `ws://127.0.0.1:8788/ws/telemetry` and press **Connect source**.
5. Verify status becomes **CONNECTED** and the **Wi-Fi / LAN Data Integrity Observatory** displays accepted samples/s, throughput, median round-trip time, and a link-health score.
6. Select **Live**, choose **Galileo Measurement Lab** (or another CORE 10 experiment), and press **Start run**. A stream of synthetic readings should appear. Stop, analyze, save, and export as needed.
7. Close the console (or press Ctrl+C) to stop the Python gateway and simulator. Closing only the dashboard window does not stop the gateway.

**Always recognize the provenance:** the default demo uses synthetic data transported through real loopback TCP sockets and real WebSocket messages. It is **not a physical Wi-Fi radio or instrument test**.

## Try deliberate communication failures

In PowerShell / cmd within the extracted directory:

```bat
py -3 launch.py --demo --drop-every 5 --bad-crc-every 7 --duplicate-every 4 --delay-ms 80 --open-browser
```

Watch **Connections** -> **SEQUENCE GAPS**, **CRC / DUPLICATES**, **APP LINK HEALTH**, **THROUGHPUT**, **ROUND-TRIP**, and **UPSTREAM LAG**. Restart without fault flags to return to clean demo conditions. Error counters are cumulative for that gateway session; health is a rolling 30-second heuristic.

## Run the automated tests

```bat
py -3 -m unittest discover -s tests -v
```

Eight tests cover CRC, gaps, duplicates, out-of-order frames, RSSI provenance, recent-health recovery, TCP connection, HTTP status, and WebSocket sample/metric streaming. See `04_TEST_REPORT.md` for the verified results and limitations.

## Where to learn more

- `01_ARCHITECTURE_AND_LESSON.md`: a guided explanation of each component and a walk-through.
- `02_LINK_METRICS.md`: exact meaning and limitations of link, integrity, throughput, and lag metrics.
- `03_PROTOCOL_AND_HARDWARE.md`: wire format, ESP32 example, real node steps and security caveats.
- `04_TEST_REPORT.md`: the local automated verification report and remaining acceptance gates.
- `ARCHITECTURE.svg`: labeled, printable teaching diagram.

**Historical coexistence:** This is an independent v0.6 *sidecar*. It **does not overwrite or automatically integrate with** the earlier SUPER SDL v0.7 Python MCP gateway (MCP port 8000, legacy ASCII/TCP device port 8765, Traffic Cop 8787). The new sidecar uses device **8766** and dashboard HTTP/WebSocket **8788** by default. There is no direct MCP implementation in this download.
