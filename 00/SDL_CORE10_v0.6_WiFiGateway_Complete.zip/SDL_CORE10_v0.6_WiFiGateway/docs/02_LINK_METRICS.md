# Wi-Fi/LAN communications diagnostics - precise definitions

The Python implementation is in `gateway/server.py`, especially `Metrics.snapshot`, `LabGateway.handle_device`, `LabGateway.connect_device`, and `LabGateway.heartbeat`. A WebSocket metrics snapshot is broadcast each second. Query `http://127.0.0.1:8788/api/status` for the same information without a browser.

| Metric / JSON field | Computation | Interpretation / limitation |
|---|---|---|
| `connected` | Active TCP socket to node | Reachability only; not data correctness |
| `app_link_health_score` | Start 100; subtract recent CRC (3 each), gap (2 each), duplicate (2 each), reordered (3 each), parse (1 each) errors in **30 seconds**; 0 when disconnected; capped at 40 when accepted data stale >3s | **Custom heuristic**, not a Wi-Fi standard or RF quality percentage |
| `samples_total` | Count of accepted unique in-order samples | Excludes duplicate/out-of-order/rejected samples |
| `missing_samples` | Forward jumps in sequence count, summed | Samples missing **at application layer**; not direct evidence of Wi-Fi packet loss |
| `duplicate_samples` | Repeated last sequence number | Application-level duplicate samples |
| `out_of_order` | Sequence lower than latest accepted value | Out-of-order delivery/replay, not accepted |
| `crc_errors` | Wrong CRC32 for canonical JSON body | Detects accidental envelope corruption; **not** a cryptographic integrity/authentication guarantee |
| `parse_errors` | Malformed/invalid JSON or invalid field types | Includes invalid device messages |
| `integrity_pct` | `100*accepted / (accepted + missing + crc_errors)` | Approximate success indicator; denominator may count an error twice when CRC rejection also produces a sequence gap |
| `throughput_bytes_s` | Sum of bytes in **accepted** sample envelopes over 5 seconds / 5 | Not aggregate TCP/Ethernet/Wi-Fi throughput; excludes rejected frames, ACK, ping, retransmit, framing and browser traffic |
| `throughput_kbit_s` | `8*throughput_bytes_s / 1000` | Application goodput, decimal kb/s |
| `data_rate_samples_s` | Number of accepted samples in past 5 sec / 5 | Includes startup averaging window, so starts below steady-state |
| `rtt_ms`, `rtt_p95_ms` | Measured node ping-to-pong time; median and approximate 95th percentile of most recent 120 | End-to-end **round-trip** response including processing; not raw Wi-Fi latency |
| `estimated_upstream_lag_ms` | Node monotonic timestamp mapped to Python monotonic with ping midpoint clock offset, sampled arrival minus mapped send | Estimated one-way application delay, not true RF flight time |
| `clock_uncertainty_ms` | Approx. most recent RTT/2 | Rough uncertainty under symmetric delay assumption; may be worse on asymmetric/jittery network |
| `arrival_jitter_ms` | Deviation of arrival spacing from declared sample period, median of last 150 | Includes host scheduling, sample gaps and simulator timing effects |
| `last_sample_age_s` | Time since last accepted sample | Helpful for identifying a stale yet connected instrument |
| `rssi_dbm` | Directly **reported by node** when supplied | TCP alone cannot measure Wi-Fi RSSI; no value means **unavailable**, not zero |
| `reconnects` | TCP reconnections after an earlier successful session | Not the count of Wi-Fi association failures |

### Conceptual integrity layers

1. **Device recording:** Did the sensor make the reading? Are timestamps/units calibrated?
2. **Application numbering:** Did every expected acquisition sequence appear? This detects some missing observations.
3. **Envelope CRC32:** Did message body bytes match its checksum? Does not authenticate the sender.
4. **TCP:** Ordered, reliable byte stream between endpoints; transport retransmissions are not represented by application sample gaps.
5. **Gateway acceptance and archive:** Were valid readings accepted, indexed and logged?
6. **WebSocket display:** Did the current browser receive and plot them? A slow browser may drop enqueued UI messages independently of device acquisition.

For an actual instrument, the most important numbers to watch together are accepted sample rate vs requested sample rate, sequence gaps, sample age, reconnects, RTT/lag, and the instrument's own RSSI when available. One green score alone is insufficient.
