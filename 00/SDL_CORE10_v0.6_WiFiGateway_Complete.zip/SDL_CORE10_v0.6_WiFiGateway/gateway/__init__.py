"""SDL gateway package."""
